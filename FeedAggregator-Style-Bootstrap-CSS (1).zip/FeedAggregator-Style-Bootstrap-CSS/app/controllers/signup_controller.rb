class SignupController < ApplicationController
end
