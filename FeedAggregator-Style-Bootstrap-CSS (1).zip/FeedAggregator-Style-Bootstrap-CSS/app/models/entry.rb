class Entry < ApplicationRecord
  belongs_to :feed
end
