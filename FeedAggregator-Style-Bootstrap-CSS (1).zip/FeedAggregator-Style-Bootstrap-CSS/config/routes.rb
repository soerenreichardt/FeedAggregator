Rails.application.routes.draw do

  get 'pages/signup'

root 'pages#home'



  get "about" => "pages#about", as: :about

  get "workspace" => "pages#workspace", as: :workspace

  get "signup" => "signup#signup", as: :signup

  resources :feeds do
    member do
      resources :entries, only: [:index, :show]
    end
  end

  resources :feeds
  root 'feeds#index'
  
  #root 'static_pages#home'

  get 		'/help', 	to: 'static_pages#help'
  get 		'/contact', to: 'static_pages#contact'
  
  get 		'/login', 	to: 'sessions#new'
  post 		'/login', 	to: 'sessions#create'
  delete 	'/logout',	to: 'sessions#destroy'
  resources :users
end
